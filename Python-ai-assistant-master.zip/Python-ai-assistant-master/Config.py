# Open weather map details

AUTH_KEY = 'ab46492c5e954d033a7e4a6afe58ccde'

BASE_CITY = 'Rathnapura'

# Database Details

HOST_NAME = 'localhost'

USER_NAME = 'root'

PASSWORD = ''

DATABASE_NAME = 'data_store'

# Push Bullet API details

API_KEY = 'o.SwB5RE7PBYNdAOSSjOBE60FRalj4MECx'

# Wolfram|Alpha API details

API_Wolfram = '8J6WWY-UGHA9R6UE4'

# TMDB API key

TMDB_API_KEY = "da331723a5f297e93f44f6dc2695d523"






